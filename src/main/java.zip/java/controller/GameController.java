package controller;

import model.ShootingBall;

public class GameController {
    public static void shoot(ShootingBall ball) {

    }
}
